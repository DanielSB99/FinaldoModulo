<?php $__env->startSection('title', 'Editar Estúdio - PokéCenter'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center py-4">
    <div class="col-md-8">

        <div class="card shadow-sm border-0">
            <div class="card-header bg-danger text-white fw-bold">
                Editar Estúdio: <?php echo e($estudio->nome_do_estudio); ?>

            </div>

            <div class="card-body p-4">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="/estudios/<?php echo e($estudio->id); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label for="nome_do_estudio" class="form-label fw-bold">Nome do Estúdio *</label>
                        <input type="text" class="form-control" id="nome_do_estudio" name="nome_do_estudio"
                               value="<?php echo e(old('nome_do_estudio', $estudio->nome_do_estudio)); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="descricao" class="form-label fw-bold">Descrição</label>
                        <textarea class="form-control" id="descricao" name="descricao"
                                  rows="3"><?php echo e(old('descricao', $estudio->descricao)); ?></textarea>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="ano_fundacao" class="form-label fw-bold">Ano de Fundação</label>
                            <input type="number" class="form-control" id="ano_fundacao" name="ano_fundacao"
                                   value="<?php echo e(old('ano_fundacao', $estudio->ano_fundacao)); ?>"
                                   min="1900" max="<?php echo e(date('Y')); ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="logotipo" class="form-label fw-bold">Logotipo</label>

                            
                            <?php if($estudio->logotipo): ?>
                                <div class="mb-2">
                                    <img src="<?php echo e(asset('storage/' . $estudio->logotipo)); ?>"
                                         alt="Logotipo atual" style="max-height: 80px; border-radius: 6px;">
                                    <p class="form-text">Logotipo atual. Carrega um novo para substituir.</p>
                                </div>
                            <?php endif; ?>

                            <input type="file" class="form-control" id="logotipo"
                                   name="logotipo" accept="image/*">
                            <div class="form-text">Formatos aceites: JPG, PNG, GIF. Máximo 2MB. Deixa em branco para manter o logotipo atual.</div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="/estudios" class="btn btn-outline-secondary">Cancelar</a>
                        <button type="submit" class="btn btn-danger px-4">Guardar Alterações</button>
                    </div>
                </form>

            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\danie\Desktop\trabalhos\WebServidor_React\TrabalhoFimModulo\TarefaPokemon\resources\views/estudios/edit.blade.php ENDPATH**/ ?>