<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Pokémon CRM'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-danger shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="/">PokéCenter</a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/estudios">Estúdios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/jogos">Jogos</a>
                    </li>
                </ul>

                <ul class="navbar-nav">
                    
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item d-flex align-items-center">
                            <a class="nav-link" href="/login">Entrar</a>
                        </li>
                        <li class="nav-item d-flex align-items-center">
                            <a class="btn btn-outline-light btn-sm ms-2" href="/register">Registar</a>
                        </li>
                    <?php endif; ?>

                    
                    <?php if(auth()->guard()->check()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/dashboard">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <span class="nav-link text-white ms-3">
                                Olá, <strong><?php echo e(Auth::user()->name); ?></strong>!
                            </span>
                        </li>
                        <li class="nav-item">
                            <form action="/logout" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="nav-link btn btn-link text-white-50">Sair</button>
                            </form>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <main class="container mt-5">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\danie\Desktop\trabalhos\WebServidor_React\TrabalhoFimModulo\TarefaPokemon\resources\views/layout/layout.blade.php ENDPATH**/ ?>