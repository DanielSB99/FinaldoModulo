<?php $__env->startSection('title', 'Lista de Estúdios - PokéCenter'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-danger fw-bold">Estúdios Pokémon</h2>

        <?php if(Auth::check() && Auth::user()->tipo == 1): ?>
            <a href="/estudios/create" class="btn btn-danger">+ Novo Estúdio</a>
        <?php endif; ?>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <form method="GET" action="/estudios" class="mb-4">
        <div class="input-group">
            <input type="text" class="form-control" name="pesquisa"
                   placeholder="Pesquisar estúdio por nome..."
                   value="<?php echo e(request('pesquisa')); ?>">
            <button class="btn btn-danger" type="submit">Pesquisar</button>
            <?php if(request('pesquisa')): ?>
                <a href="/estudios" class="btn btn-outline-secondary">Limpar</a>
            <?php endif; ?>
        </div>
    </form>

    
    <?php if(request('pesquisa')): ?>
        <p class="text-muted mb-3">
            A mostrar resultados para: <strong>"<?php echo e(request('pesquisa')); ?>"</strong>
            — <?php echo e(count($estudios)); ?> resultado(s) encontrado(s)
        </p>
    <?php endif; ?>

    <div class="row row-cols-1 row-cols-md-3 g-4">

        <?php $__empty_1 = true; $__currentLoopData = $estudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col">
                <div class="card h-100 shadow-sm border-0">

                    <div class="bg-light text-center p-3" style="height: 150px; display: flex; align-items: center; justify-content: center;">
                        <?php if($estudio->logotipo): ?>
                            <img src="<?php echo e(asset('storage/' . $estudio->logotipo)); ?>"
                                 alt="<?php echo e($estudio->nome_do_estudio); ?>"
                                 class="img-fluid" style="max-height: 100%;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/default.jpg')); ?>"
                                 alt="Sem logotipo" class="img-fluid" style="max-height: 100%;">
                        <?php endif; ?>
                    </div>

                    <div class="card-body text-center">
                        <h5 class="card-title fw-bold"><?php echo e($estudio->nome_do_estudio); ?></h5>

                        <?php if($estudio->ano_fundacao): ?>
                            <p class="text-muted small mb-1">Fundado em <?php echo e($estudio->ano_fundacao); ?></p>
                        <?php endif; ?>

                        <p class="text-muted small mb-3">
                            <span class="badge bg-secondary"><?php echo e($estudio->jogos_count); ?> Jogos Registados</span>
                        </p>

                        <a href="/estudios/<?php echo e($estudio->id); ?>/jogos" class="btn btn-outline-danger w-100 mb-2">Ver Jogos</a>

                        <?php if(Auth::check() && Auth::user()->tipo == 1): ?>
                            <a href="/estudios/<?php echo e($estudio->id); ?>/edit" class="btn btn-outline-primary btn-sm w-100 mb-1">Editar</a>

                            <form action="/estudios/<?php echo e($estudio->id); ?>" method="POST"
                                  onsubmit="return confirm('Tens a certeza que queres apagar o estúdio \'<?php echo e($estudio->nome_do_estudio); ?>\'? Todos os jogos associados serão também apagados!');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-outline-danger btn-sm w-100">Apagar</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted mb-0">Nenhum estúdio encontrado.</p>
            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\danie\Desktop\trabalhos\WebServidor_React\TrabalhoFimModulo\TarefaPokemon\resources\views/estudios/estudios.blade.php ENDPATH**/ ?>