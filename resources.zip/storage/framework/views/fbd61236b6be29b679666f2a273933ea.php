<?php $__env->startSection('title', isset($estudio) ? 'Jogos - ' . $estudio->nome_do_estudio : 'Todos os Jogos - PokéCenter'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-danger fw-bold">
            <?php if(isset($estudio)): ?>
                Jogos do Estúdio: <?php echo e($estudio->nome_do_estudio); ?>

            <?php else: ?>
                Todos os Jogos Pokémon
            <?php endif; ?>
        </h2>

        <?php if(Auth::check() && Auth::user()->tipo == 1): ?>
            <a href="/jogos/create" class="btn btn-danger">+ Novo Jogo</a>
        <?php endif; ?>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <?php if(!isset($estudio)): ?>
        <form method="GET" action="/jogos" class="mb-4">

            
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="pesquisa"
                       placeholder="Pesquisar jogo por nome..."
                       value="<?php echo e(request('pesquisa')); ?>">
                <button class="btn btn-danger" type="submit">Pesquisar</button>
                <?php if(request()->hasAny(['pesquisa', 'genero', 'plataforma', 'pegi', 'ano'])): ?>
                    <a href="/jogos" class="btn btn-outline-secondary">Limpar Filtros</a>
                <?php endif; ?>
            </div>

            
            <div class="row g-2">
                <div class="col-md-3">
                    <select name="genero" class="form-select form-select-sm">
                        <option value="">-- Género --</option>
                        <?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($g); ?>" <?php echo e(request('genero') == $g ? 'selected' : ''); ?>>
                                <?php echo e($g); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="plataforma" class="form-select form-select-sm">
                        <option value="">-- Plataforma --</option>
                        <?php $__currentLoopData = $plataformas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p); ?>" <?php echo e(request('plataforma') == $p ? 'selected' : ''); ?>>
                                <?php echo e($p); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="pegi" class="form-select form-select-sm">
                        <option value="">-- PEGI --</option>
                        <?php $__currentLoopData = $pegis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pegi); ?>" <?php echo e(request('pegi') == $pegi ? 'selected' : ''); ?>>
                                PEGI <?php echo e($pegi); ?>+
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="ano" class="form-select form-select-sm">
                        <option value="">-- Ano de Lançamento --</option>
                        <?php $__currentLoopData = $anos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ano): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ano); ?>" <?php echo e(request('ano') == $ano ? 'selected' : ''); ?>>
                                <?php echo e($ano); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </form>

        
        <?php if(request()->hasAny(['pesquisa', 'genero', 'plataforma', 'pegi', 'ano'])): ?>
            <p class="text-muted mb-3"><?php echo e(count($jogos)); ?> resultado(s) encontrado(s)</p>
        <?php endif; ?>
    <?php endif; ?>

    <div class="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">
        <?php $__empty_1 = true; $__currentLoopData = $jogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jogo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col">
                <div class="card h-100 shadow-sm border-0">

                    <div class="bg-dark text-center" style="height: 250px; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                        <?php if($jogo->imagem_capa): ?>
                            <img src="<?php echo e(asset('storage/' . $jogo->imagem_capa)); ?>"
                                 alt="<?php echo e($jogo->nome_do_jogo); ?>"
                                 class="img-fluid" style="min-height: 100%; object-fit: cover;">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/default.jpg')); ?>"
                                 alt="Sem capa"
                                 class="img-fluid" style="min-height: 100%; object-fit: cover;">
                        <?php endif; ?>
                    </div>

                    <div class="card-body">
                        <h5 class="card-title fw-bold text-truncate" title="<?php echo e($jogo->nome_do_jogo); ?>">
                            <?php echo e($jogo->nome_do_jogo); ?>

                        </h5>

                        <ul class="list-unstyled small text-muted mb-3 mt-3">
                            <li><strong>Plataforma:</strong> <?php echo e($jogo->plataforma ?? 'N/A'); ?></li>
                            <li><strong>Lançamento:</strong> <?php echo e($jogo->data_lancamento ? \Carbon\Carbon::parse($jogo->data_lancamento)->format('d/m/Y') : 'N/A'); ?></li>
                            <li><strong>Género:</strong> <?php echo e($jogo->genero ?? 'N/A'); ?></li>
                            <li><strong>PEGI:</strong> <?php echo e($jogo->pegi ?? 3); ?>+</li>
                        </ul>
                    </div>

                    <?php if(auth()->guard()->check()): ?>
                        <div class="card-footer bg-white border-top-0 pb-3">
                            <div class="d-flex gap-2">
                                <a href="/jogos/<?php echo e($jogo->id); ?>/edit" class="btn btn-sm btn-outline-primary flex-fill">Editar</a>

                                <?php if(Auth::user()->tipo == 1): ?>
                                    <form action="/jogos/<?php echo e($jogo->id); ?>" method="POST" class="flex-fill"
                                          onsubmit="return confirm('Tens a certeza que queres apagar este jogo?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger w-100">Apagar</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted mb-0">Nenhum jogo encontrado.</p>
            </div>
        <?php endif; ?>
    </div>

    <?php if(isset($estudio)): ?>
        <div class="mt-4">
            <a href="/estudios" class="btn btn-secondary">&larr; Voltar aos Estúdios</a>
        </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\danie\Desktop\trabalhos\WebServidor_React\TrabalhoFimModulo\TarefaPokemon\resources\views/jogos/jogos.blade.php ENDPATH**/ ?>