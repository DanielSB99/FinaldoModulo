<?php $__env->startSection('title', 'Novo Jogo - PokéCenter'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center py-4">
    <div class="col-md-8">

        <div class="card shadow-sm border-0">
            <div class="card-header bg-danger text-white fw-bold">
                Adicionar Novo Jogo Pokémon
            </div>

            <div class="card-body p-4">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                
                <form action="/jogos" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="nome_do_jogo" class="form-label fw-bold">Nome do Jogo *</label>
                        <input type="text" class="form-control" id="nome_do_jogo" name="nome_do_jogo"
                               value="<?php echo e(old('nome_do_jogo')); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="estudio_id" class="form-label fw-bold">Estúdio Responsável *</label>
                        <select class="form-select" id="estudio_id" name="estudio_id" required>
                            <option value="">-- Selecionar Estúdio --</option>
                            <?php $__currentLoopData = $estudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($estudio->id); ?>"
                                    <?php echo e(old('estudio_id') == $estudio->id ? 'selected' : ''); ?>>
                                    <?php echo e($estudio->nome_do_estudio); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="plataforma" class="form-label fw-bold">Plataforma</label>
                            <input type="text" class="form-control" id="plataforma" name="plataforma"
                                   value="<?php echo e(old('plataforma')); ?>" placeholder="Ex: Nintendo Switch">
                        </div>
                        <div class="col-md-6">
                            <label for="data_lancamento" class="form-label fw-bold">Data de Lançamento</label>
                            <input type="date" class="form-control" id="data_lancamento" name="data_lancamento"
                                   value="<?php echo e(old('data_lancamento')); ?>">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="genero" class="form-label fw-bold">Género</label>
                            <input type="text" class="form-control" id="genero" name="genero"
                                   value="<?php echo e(old('genero')); ?>" placeholder="Ex: RPG">
                        </div>
                        <div class="col-md-6">
                            <label for="pegi" class="form-label fw-bold">Classificação PEGI</label>
                            <input type="number" class="form-control" id="pegi" name="pegi"
                                   value="<?php echo e(old('pegi', 3)); ?>" min="3" max="18">
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="imagem_capa" class="form-label fw-bold">Imagem de Capa</label>
                        <input type="file" class="form-control" id="imagem_capa"
                               name="imagem_capa" accept="image/*">
                        <div class="form-text">Formatos aceites: JPG, PNG, GIF. Máximo 2MB.</div>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="/jogos" class="btn btn-outline-secondary">Cancelar</a>
                        <button type="submit" class="btn btn-danger px-4">Guardar Jogo</button>
                    </div>
                </form>

            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\danie\Desktop\trabalhos\WebServidor_React\TrabalhoFimModulo\TarefaPokemon\resources\views/jogos/jogosCreate.blade.php ENDPATH**/ ?>