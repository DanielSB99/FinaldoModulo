<?php $__env->startSection('title', 'Lista de Estúdios - PokéCenter'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-danger fw-bold">Estúdios Pokémon</h2>


        <?php if(Auth::check() && Auth::user()->tipo == 1): ?>
            <a href="/estudios/create" class="btn btn-danger">+ Novo Estúdio</a>
        <?php endif; ?>
    </div>

    <div class="row row-cols-1 row-cols-md-3 g-4">

        <?php $__empty_1 = true; $__currentLoopData = $estudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col">
                <div class="card h-100 shadow-sm border-0">

                    <div class="bg-light text-center p-3" style="height: 150px; display: flex; align-items: center; justify-content: center;">
                        <?php if($estudio->logotipo): ?>
                            <img src="<?php echo e(asset('storage/' . $estudio->logotipo)); ?>" alt="<?php echo e($estudio->nome_do_estudio); ?>" class="img-fluid" style="max-height: 100%;">
                        <?php else: ?>
                            <span class="text-muted">Sem Imagem</span>
                        <?php endif; ?>
                    </div>

                    <div class="card-body text-center">
                        <h5 class="card-title fw-bold"><?php echo e($estudio->nome_do_estudio); ?></h5>


                        <p class="text-muted small mb-3">
                            <span class="badge bg-secondary"><?php echo e($estudio->jogos_count); ?> Jogos Registados</span>
                        </p>


                        <a href="/estudios/<?php echo e($estudio->id); ?>/jogos" class="btn btn-outline-danger w-100">Ver Jogos</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted mb-0">Ainda não existem estúdios registados no sistema.</p>
                <small>A aguardar que o Professor Oak insira os dados iniciais!</small>
            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\danie\Desktop\trabalhos\WebServidor_React\TrabalhoFimModulo\TarefaPokemon\resources\views/tables/estudios.blade.php ENDPATH**/ ?>