<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\danie\Desktop\trabalhos\WebServidor_React\TrabalhoFimModulo\TarefaPokemon\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>