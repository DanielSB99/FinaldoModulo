<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('estudios_table', function (Blueprint $table) {
            $table->id();
            $table->string('nome_do_estudio');
            $table->string('logotipo')->nullable();
            $table->text('descricao')->nullable();
            $table->integer('ano_fundacao')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
       Schema::dropIfExists('estudios_table');
    }
};
